# TIERLIST OF SWORD IN SAILOR PIECE

A Pen created on CodePen.

Original URL: [https://codepen.io/Charles-Andrei-the-vuer/pen/wBzOywV](https://codepen.io/Charles-Andrei-the-vuer/pen/wBzOywV).

